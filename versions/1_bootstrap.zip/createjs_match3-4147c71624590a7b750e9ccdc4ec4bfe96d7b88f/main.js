(function() {

    window.initialize = function() {
        
    };

})();
